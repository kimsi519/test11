/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./ex1/**/*.{html,js}"],
  theme: {
    extend: {},
  },
  plugins: [],
};
